<aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
        
                   <h1>AVMS</h1>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a href="dashboard.php"  style="color: blue">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>
     <li><a href="category.php"  style="color: blue">
                            <i class="fa fa-files-o"></i>Categories</a>
                        </li>



     <li><a href="visitors-form.php"  style="color: blue">
                            <i class="fa fa-user"></i>New Visitor</a>
                        </li>
   <li>
                            <a href="manage-newvisitors.php"  style="color: blue">
                                <i class="fa fa-users"></i>Manage Visitors</a>
                        </li>

<li class="has-sub">
<a class="js-arrow open" href="#">
<i class="fas fa-copy"></i>Entry Pass</a>
<ul class="list-unstyled navbar__sub-list js-sub-list">
<li>
<a href="create-pass.php">Create</a>
</li>
<li>
<a href="manage-passes.php">Manage</a>
</li>
</ul>
</li>


                        
                      <li>
                            <a href="bwdates-reports.php"  style="color: blue">
                                <i class="fas fa-copy"></i>Vistors B/w Dates</a>
                        </li>  

                      <li>
                            <a href="bwdates-passreports.php"  style="color: blue">
                                <i class="fas fa-copy"></i>Pass B/w Dates</a>
                        </li>  

                       
                    </ul>
                </nav>
            </div>
        </aside>